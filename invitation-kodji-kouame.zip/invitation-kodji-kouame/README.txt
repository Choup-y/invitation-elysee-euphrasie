INVITATION DE MARIAGE — ELYSÉE & EUPHRASIE

FICHIERS
- index.html : site complet (HTML, CSS et JavaScript)
- photos/ : vos 5 photos actuelles, remplaçables en conservant les noms de fichiers

AVANT DE PUBLIER
1. Ouvrez index.html dans un éditeur de texte.
2. En haut du script, vérifiez WEDDING_DATE. La date confirmée est le samedi 10 avril 2027 à 09h30. Pensez à compléter la date limite de réponse RSVP.
3. Remplacez « DATE LIMITE À COMPLÉTER » par votre date limite de réponse.
4. Pour le RSVP, renseignez soit RSVP_FORM_URL avec l’URL de votre Google Forms, soit WHATSAPP_NUMBER avec le numéro international sans +. Sans cela, le formulaire téléchargera un fichier texte au lieu d’envoyer automatiquement la réponse.
5. Les lieux sont présentés comme cérémonie à la Mairie de Cocody et réception à The Rezy Event & Lounge : vérifiez que c’est bien votre organisation.

REMPLACER LES PHOTOS
Remplacez les fichiers dans photos/ en gardant exactement les noms :
photo-accueil.png, photo-2.png, photo-3.png, photo-4.png, photo-5.png.
La première photo jointe est utilisée pour l’accueil. Les autres sont utilisées dans la galerie.

PUBLIER GRATUITEMENT AVEC GITHUB + VERCEL
1. Connectez-vous à github.com et créez un compte si nécessaire.
2. Cliquez sur New repository, nommez-le par exemple invitation-elysee-euphrasie, puis créez-le.
3. Sur la page du dépôt, choisissez Add file > Upload files.
4. Glissez-déposez index.html et le dossier photos (avec ses images). Cliquez sur Commit changes.
5. Connectez-vous à vercel.com avec votre compte GitHub.
6. Choisissez Add New > Project, puis Import le dépôt invitation-elysee-euphrasie.
7. Pour un site HTML statique, gardez les réglages par défaut. Si Vercel demande un framework, choisissez Other ; laissez le build command vide et le dossier de sortie à la racine (./).
8. Cliquez sur Deploy. À la fin, Vercel fournit une adresse en .vercel.app.
9. Ouvrez le lien sur votre téléphone et testez le bouton d’ouverture, les photos et le RSVP.
10. Pour modifier le site plus tard, modifiez les fichiers sur GitHub et validez les changements : Vercel redéploiera automatiquement.

CONSEIL
Pour une collecte fiable des confirmations, créez un Google Forms avec nom, présence et nombre de personnes, puis collez son lien dans RSVP_FORM_URL. Le bouton ouvrira ce formulaire. Si vous préférez WhatsApp, renseignez WHATSAPP_NUMBER.
